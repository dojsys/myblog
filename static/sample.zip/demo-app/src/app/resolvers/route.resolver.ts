import { Injectable } from '@angular/core';
import { UsersListService } from './../service/users-list.service';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { Observable, of, Subscription } from 'rxjs';
import { map, catchError } from 'rxjs/operators';


@Injectable()
export class RouteResolver implements Resolve<any> {
   subscription: Subscription;

   constructor(public usersListService: UsersListService) { }

   resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> | boolean {
      const id = route.params['id'];

      return new Promise((resolve, reject) => {
         this.subscription = this.usersListService.getUsers().pipe(
            catchError((error) => {
               return of('No data');
            })
         ).subscribe(data => {
            if (data) {
               console.log("data loaded from resolver", data);

               resolve({
                  users: data
               });
            }
            else {
               resolve(false);
               // redirect here
            }
         }, reject);
      });
   }
}
