import { map } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { UsersListService } from './../../service/users-list.service';
import { ActivatedRoute } from '@angular/router';
import { of, Observable, BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})

export class UsersComponent implements OnInit {

  Users: Observable<any>;

  constructor(
    private usersListService: UsersListService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    // Can access route resolver data with ActivatedRoute route service

    // Get data directly from snapshot
    // const { users } = this.route.snapshot.data.routeResolver;
    // this.Users = users;
    // console.log(this.Users);

    // Get data from subscription
    this.route.data
       .subscribe(({ routeResolver: { users } }) => {
          this.Users = users;
          console.log(this.Users);
    });

    // // Get data through api and its blocking...
    // this.usersListService.getUsers().subscribe((data: {}) => {
    //   console.log("data loaded from service call", data);
    //   this.Users = data;
    // })
  }

}